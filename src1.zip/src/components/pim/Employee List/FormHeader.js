import React from 'react'

const FormHeader = () => {
  return (
    <div className="form-header mt-3 ">
        <h4 className="ms-4">Employee Information</h4>
    </div>
  )
}

export default FormHeader