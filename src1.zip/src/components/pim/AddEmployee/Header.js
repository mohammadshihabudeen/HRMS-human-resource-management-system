import React from 'react'

const Header = () => {
  return (
    <div className='addemp form-header'><p className="h4 mt-3 ms-4">Add Employee</p></div>
  )
}

export default Header