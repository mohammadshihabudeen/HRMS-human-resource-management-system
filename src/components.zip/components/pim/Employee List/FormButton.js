
const FormButton = () => {

  return (
    <>
    <div className="btn-group me-3 mt-2">
    <button type="submit" className="btn text-white" style={{ backgroundColor: "#999b30" }}>Search</button>
    </div>
    
    </>
  )
}

export default FormButton